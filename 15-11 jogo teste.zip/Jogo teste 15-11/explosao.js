
var SOM_EXPLOSAO = new Audio();
SOM_EXPLOSAO.src = 'sound/explosao.mp3';
SOM_EXPLOSAO.volume = 0.4;
SOM_EXPLOSAO.load();

var nave = this;
exp1.fimDaExplosao = function() {
nave.vidasExtras--;
if (nave.vidasExtras < 0) {
if (nave.acabaramVidas)
nave.acabaramVidas();
}
else {
// Recolocar a nave no engine
nave.colisor.novoSprite(nave);
nave.animacao.novoSprite(nave);
nave.posicionar();
} }


function Explosao(context, imagem, x, y) {
   this.context = context;
   this.imagem = imagem;
   this.spritesheet = new Spritesheet(context, imagem, 1, 5);
   this.spritesheet.intervalo = 75; // Atraso entre os quadros
   this.x = x;
   this.y = y;
   this.animando = false;
   SOM_EXPLOSAO.currentTime = 0.0;
   SOM_EXPLOSAO.play();
   var explosao = this;
   this.fimDaExplosao = null;
   
   // A função que será chamada quando o ciclo de animação da explosão terminar
   this.spritesheet.fimDoCiclo = function() {
      explosao.animacao.excluirSprite(explosao); // Exclui o sprite da animação
      if (explosao.fimDaExplosao) explosao.fimDaExplosao(); // Chama a função de término da explosão (se definida)
   }
   
   // Reproduz o som da explosão, começando do início (caso tenha tocado antes)

}

Explosao.prototype = {
   atualizar: function() {
      // Aqui você pode atualizar qualquer lógica de explosão, se necessário
   },
   
   desenhar: function() {
      // Desenha o próximo quadro da animação da explosão
      this.spritesheet.desenhar(this.x, this.y);
      this.spritesheet.proximoQuadro(); // Avança para o próximo quadro
   }
}



